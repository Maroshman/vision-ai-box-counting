#!/usr/bin/env python3
"""
Debug script to test image upload and validation
"""

import requests
import sys
from pathlib import Path

def test_image_upload(image_path, api_url="http://127.0.0.1:8000"):
    """Test image upload with detailed error reporting"""
    
    if not Path(image_path).exists():
        print(f"❌ Image file not found: {image_path}")
        return
    
    print(f"🔍 Testing image upload: {image_path}")
    print(f"📁 File size: {Path(image_path).stat().st_size} bytes")
    
    try:
        # Test health first
        health_response = requests.get(f"{api_url}/health")
        if health_response.status_code != 200:
            print(f"❌ API health check failed: {health_response.status_code}")
            return
        print("✅ API is healthy")
        
        # Test image upload
        with open(image_path, 'rb') as f:
            files = {'file': (Path(image_path).name, f, 'image/jpeg')}
            print(f"📤 Uploading with content-type: image/jpeg")
            
            response = requests.post(f"{api_url}/count-boxes", files=files)
            
            print(f"📨 Response status: {response.status_code}")
            print(f"📨 Response headers: {dict(response.headers)}")
            
            if response.status_code == 200:
                print("✅ Upload successful!")
                data = response.json()
                print(f"📊 Analysis result: {data}")
            else:
                print(f"❌ Upload failed")
                try:
                    error_data = response.json()
                    print(f"🔍 Error details: {error_data}")
                except:
                    print(f"🔍 Raw error response: {response.text}")
                    
    except Exception as e:
        print(f"❌ Error during upload: {e}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python debug_upload.py <image_path>")
        print("Example: python debug_upload.py test_image.jpg")
        return
    
    image_path = sys.argv[1]
    test_image_upload(image_path)

if __name__ == "__main__":
    main()