#!/usr/bin/env python3
"""
Test script for Vision AI Box Counting API
"""

import requests
import json
import sys
import os
from pathlib import Path

API_BASE_URL = "http://127.0.0.1:8000"

def test_health():
    """Test the health endpoint"""
    print("🔍 Testing health endpoint...")
    try:
        response = requests.get(f"{API_BASE_URL}/health")
        if response.status_code == 200:
            print("✅ Health check passed")
            print(f"   Response: {response.json()}")
        else:
            print(f"❌ Health check failed: {response.status_code}")
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API. Make sure the server is running.")
        return False
    except Exception as e:
        print(f"❌ Health check error: {e}")
        return False
    return True

def test_root():
    """Test the root endpoint"""
    print("\n🔍 Testing root endpoint...")
    try:
        response = requests.get(f"{API_BASE_URL}/")
        if response.status_code == 200:
            print("✅ Root endpoint working")
            data = response.json()
            print(f"   API: {data.get('message')}")
            print(f"   Version: {data.get('version')}")
        else:
            print(f"❌ Root endpoint failed: {response.status_code}")
    except Exception as e:
        print(f"❌ Root endpoint error: {e}")

def test_box_counting(image_path: str):
    """Test the box counting endpoint"""
    print(f"\n🔍 Testing box counting with image: {image_path}")
    
    if not os.path.exists(image_path):
        print(f"❌ Image file not found: {image_path}")
        return
    
    try:
        with open(image_path, 'rb') as f:
            files = {'file': (os.path.basename(image_path), f, 'image/jpeg')}
            response = requests.post(f"{API_BASE_URL}/count-boxes", files=files)
        
        if response.status_code == 200:
            print("✅ Box counting successful")
            data = response.json()
            print(f"   Filename: {data.get('filename')}")
            print(f"   File size: {data.get('file_size_bytes')} bytes")
            
            analysis = data.get('analysis', {})
            if 'total_count' in analysis:
                print(f"   📦 Total boxes found: {analysis['total_count']}")
                print(f"   🏷️  Confidence: {analysis.get('confidence_score', 'N/A')}")
                
                summary = analysis.get('summary', {})
                if summary:
                    print(f"   📊 Boxes with labels: {summary.get('boxes_with_labels', 0)}")
                    common_labels = summary.get('common_labels', [])
                    if common_labels:
                        print(f"   🔤 Common labels: {', '.join(common_labels)}")
            else:
                print(f"   Raw output: {analysis.get('raw_output', 'No output')}")
                
        else:
            print(f"❌ Box counting failed: {response.status_code}")
            try:
                error_data = response.json()
                print(f"   Error: {error_data.get('detail', 'Unknown error')}")
            except:
                print(f"   Error response: {response.text}")
                
    except Exception as e:
        print(f"❌ Box counting error: {e}")

def test_simple_endpoint(image_path: str):
    """Test the simplified box counting endpoint"""
    print(f"\n🔍 Testing simple box counting with image: {image_path}")
    
    if not os.path.exists(image_path):
        print(f"❌ Image file not found: {image_path}")
        return
    
    try:
        with open(image_path, 'rb') as f:
            files = {'file': (os.path.basename(image_path), f, 'image/jpeg')}
            response = requests.post(f"{API_BASE_URL}/count-boxes-simple", files=files)
        
        if response.status_code == 200:
            print("✅ Simple box counting successful")
            data = response.json()
            
            if 'count' in data:
                print(f"   📦 Count: {data['count']}")
                print(f"   🏷️  Labels: {data.get('labels', [])}")
                print(f"   📊 Confidence: {data.get('confidence', 'N/A')}")
            else:
                print(f"   Raw output: {data.get('raw_output', 'No output')}")
                
        else:
            print(f"❌ Simple box counting failed: {response.status_code}")
            try:
                error_data = response.json()
                print(f"   Error: {error_data.get('detail', 'Unknown error')}")
            except:
                print(f"   Error response: {response.text}")
                
    except Exception as e:
        print(f"❌ Simple box counting error: {e}")

def main():
    """Main test function"""
    print("🚀 Vision AI Box Counting API Test Suite")
    print("=" * 50)
    
    # Test basic endpoints
    if not test_health():
        print("\n❌ Cannot proceed with tests - API is not responding")
        return
    
    test_root()
    
    # Test with image if provided
    if len(sys.argv) > 1:
        image_path = sys.argv[1]
        test_box_counting(image_path)
        test_simple_endpoint(image_path)
    else:
        print("\n💡 To test box counting, run:")
        print(f"   python {sys.argv[0]} path/to/your/image.jpg")
        
        # Look for common image files in current directory
        common_extensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif']
        current_dir = Path('.')
        image_files = []
        
        for ext in common_extensions:
            image_files.extend(current_dir.glob(f"*{ext}"))
            image_files.extend(current_dir.glob(f"*{ext.upper()}"))
        
        if image_files:
            print(f"\n📁 Found images in current directory:")
            for img in image_files[:5]:  # Show first 5
                print(f"   - {img}")
            if len(image_files) > 5:
                print(f"   ... and {len(image_files) - 5} more")
    
    print("\n✨ Test completed!")

if __name__ == "__main__":
    main()