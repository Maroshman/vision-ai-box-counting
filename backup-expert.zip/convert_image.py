#!/usr/bin/env python3
"""
Convert AVIF/HEIC images to JPEG format for testing
"""

import subprocess
import sys
from pathlib import Path

def convert_with_sips(input_path, output_path):
    """Convert image using macOS sips command"""
    try:
        cmd = ['sips', '-s', 'format', 'jpeg', input_path, '--out', output_path]
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"✅ Successfully converted {input_path} to {output_path}")
            return True
        else:
            print(f"❌ sips conversion failed: {result.stderr}")
            return False
    except Exception as e:
        print(f"❌ Error running sips: {e}")
        return False

def main():
    input_file = "stack-boxes.jpg"
    output_file = "stack-boxes-converted.jpg"
    
    if not Path(input_file).exists():
        print(f"❌ Input file not found: {input_file}")
        return
    
    print(f"🔄 Converting {input_file} to {output_file}...")
    
    if convert_with_sips(input_file, output_file):
        print(f"🎉 Conversion complete!")
        print(f"📂 You can now test with: python debug_upload.py {output_file}")
    else:
        print("❌ Conversion failed. Try manually converting the image to JPEG format.")

if __name__ == "__main__":
    main()