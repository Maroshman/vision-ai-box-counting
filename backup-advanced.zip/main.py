from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
import openai
import base64
import json
import os
from PIL import Image
import io
from typing import Dict, Any, List
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Vision AI Box Counting API",
    description="AI-powered box counting and label extraction from images",
    version="1.0.0"
)

# Initialize OpenAI client
openai.api_key = os.getenv("OPENAI_API_KEY")

def encode_image_to_base64(image_bytes: bytes) -> str:
    """Convert image bytes to base64 string for OpenAI API"""
    return base64.b64encode(image_bytes).decode('utf-8')

def validate_image(file: UploadFile) -> bool:
    """Validate if uploaded file is a valid image"""
    allowed_types = ["image/jpeg", "image/jpg", "image/png", "image/webp", "image/gif"]
    return file.content_type in allowed_types

def create_box_counting_prompt() -> str:
    """Create the AI prompt for box counting and label extraction"""
    return """
You are an expert computer vision AI specialized in counting boxes and extracting text labels from images.

Please analyze the provided image and:

1. **Count all visible boxes/packages/containers** in the image
2. **Extract any visible text labels, barcodes, or identifying information** on the boxes
3. **Identify the type of boxes** (shipping boxes, product boxes, containers, etc.)
4. **Note the arrangement/stacking** of boxes if relevant

Return your analysis in the following JSON format:
{
    "total_count": <number>,
    "box_details": [
        {
            "box_id": <sequential_number>,
            "type": "<box_type>",
            "labels": ["<text1>", "<text2>"],
            "confidence": <0.0-1.0>,
            "position": "<general_position_description>"
        }
    ],
    "summary": {
        "total_boxes": <number>,
        "boxes_with_labels": <number>,
        "common_labels": ["<frequent_labels>"],
        "arrangement": "<description_of_arrangement>"
    },
    "confidence_score": <overall_confidence_0.0-1.0>
}

Be thorough and accurate. If you cannot clearly see a box or are unsure, indicate lower confidence. If no text is visible on a box, use an empty array for labels.
"""

async def analyze_image_with_openai(image_base64: str) -> Dict[str, Any]:
    """Send image to OpenAI Vision API for box counting and label extraction"""
    try:
        response = openai.chat.completions.create(
            model="gpt-4-vision-preview",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": create_box_counting_prompt()
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_base64}",
                                "detail": "high"
                            }
                        }
                    ]
                }
            ],
            max_tokens=1000,
            temperature=0.1
        )
        
        content = response.choices[0].message.content
        
        # Try to parse JSON from the response
        try:
            # Look for JSON in the response
            json_start = content.find('{')
            json_end = content.rfind('}') + 1
            if json_start != -1 and json_end != -1:
                json_content = content[json_start:json_end]
                return json.loads(json_content)
            else:
                # Fallback: return raw content
                return {"raw_output": content}
        except json.JSONDecodeError:
            return {"raw_output": content}
            
    except Exception as e:
        logger.error(f"OpenAI API error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"AI analysis failed: {str(e)}")

@app.get("/")
def read_root():
    """Root endpoint with API information"""
    return {
        "message": "Vision AI Box Counting API",
        "version": "1.0.0",
        "endpoints": {
            "/count-boxes": "POST - Upload image for box counting and label extraction",
            "/health": "GET - Health check endpoint"
        }
    }

@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "box-counting-ai"}

@app.post("/count-boxes")
async def count_boxes(file: UploadFile = File(...)):
    """
    Count boxes and extract labels from uploaded image
    
    Args:
        file: Image file (JPEG, PNG, WebP, GIF)
        
    Returns:
        JSON response with box count and label information
    """
    try:
        # Validate file
        if not validate_image(file):
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid file type. Supported: JPEG, PNG, WebP, GIF. Got: {file.content_type}"
            )
        
        # Check file size (limit to 20MB)
        file_bytes = await file.read()
        if len(file_bytes) > 20 * 1024 * 1024:
            raise HTTPException(status_code=400, detail="File too large. Maximum size: 20MB")
        
        # Validate image can be opened
        try:
            image = Image.open(io.BytesIO(file_bytes))
            image.verify()  # Verify it's a valid image
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid or corrupted image file")
        
        # Re-read file for processing (verify() exhausts the file)
        await file.seek(0)
        file_bytes = await file.read()
        
        # Convert to base64
        image_base64 = encode_image_to_base64(file_bytes)
        
        # Analyze with OpenAI
        logger.info(f"Analyzing image: {file.filename}, size: {len(file_bytes)} bytes")
        result = await analyze_image_with_openai(image_base64)
        
        # Add metadata
        response = {
            "filename": file.filename,
            "file_size_bytes": len(file_bytes),
            "analysis": result,
            "status": "success"
        }
        
        logger.info(f"Analysis completed for {file.filename}")
        return JSONResponse(content=response)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.post("/count-boxes-simple")
async def count_boxes_simple(file: UploadFile = File(...)):
    """
    Simplified box counting endpoint that returns just the count and labels
    
    Args:
        file: Image file (JPEG, PNG, WebP, GIF)
        
    Returns:
        Simplified JSON response with count and labels
    """
    try:
        # Use the main endpoint logic
        full_response = await count_boxes(file)
        
        # Extract simplified information
        analysis = full_response["analysis"]
        
        if "total_count" in analysis:
            # Structured response
            all_labels = []
            for box in analysis.get("box_details", []):
                all_labels.extend(box.get("labels", []))
            
            simple_response = {
                "count": analysis.get("total_count", 0),
                "labels": list(set(all_labels)),  # Remove duplicates
                "confidence": analysis.get("confidence_score", 0.0)
            }
        else:
            # Fallback for raw output
            simple_response = {
                "raw_output": analysis.get("raw_output", "Analysis failed")
            }
            
        return JSONResponse(content=simple_response)
        
    except Exception as e:
        logger.error(f"Simple endpoint error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
